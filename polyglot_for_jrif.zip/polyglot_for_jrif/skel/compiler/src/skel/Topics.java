package skelpkg;

import polyglot.main.Report;

/**
 * Extension information for skel extension.
 */
public class Topics {
    public static final String skel = "skel";

    static {
        Report.topics.add(skel);
    }
}
