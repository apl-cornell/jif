package skelpkg.types;

import polyglot.types.*;

public class SkelTypeSystem_c extends TypeSystem_c implements SkelTypeSystem {
    // TODO: implement new methods in SkelTypeSystem.
    // TODO: override methods as needed from TypeSystem_c.
}
