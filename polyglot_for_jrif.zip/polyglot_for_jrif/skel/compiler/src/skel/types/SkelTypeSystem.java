package skelpkg.types;

import polyglot.types.*;

public interface SkelTypeSystem extends TypeSystem {
    // TODO: declare any new methods needed
}
